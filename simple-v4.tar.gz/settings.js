/* 

=========================================================================

  #- Credits By Skyzopedia
   Contact: https://6285624297893
   Youtube: https://youtube.com/@skyzodev
   Telegram: https://t.me/skyzodev
    
  Developer : https://wa.me/6285624297893
  
  -[ ! ]- Jangan hapus contact developer! hargai pembuat script ini

=========================================================================

*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

// Settings Bot 
global.owner = '6283807449268'
global.versi = version
global.namaOwner = "Onokosy"
global.packname = 'Onokosy'
global.botname = 'Onokosy'
global.botname2 = 'Onokosy'

global.tempatDB = 'database.json' // Jangan ubah
global.pairing_code = true // Jangan ubah

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6283807449268"
global.linkGrup = "https://chat.whatsapp.com/BK5DSUEVxFi9zPyLGcPYqC"

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3500
global.delayPushkontak = 6000

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029VauVHKAG3R3k7cXLBq1r"
global.idSaluran = "120363376806159467@newsletter"
global.namaSaluran = "Bot Whatsapp"

global.merchantIdOrderKuota = "OK2189586"
global.apiOrderKuota = "653306317374758522189586OKCT9027D06FAD22954B36D9A2593FD277A0"
global.qrisOrderKuota = ""

// Settings Api Digital Ocean
global.apiDigitalOcean = "dop_v1_a45b4adc2ed565d238f4b2cc55b227592eb0c5f6fbceda3fd2b2fe849ab0fb0e"

// Settings Api Digital Ocean
global.apiSimpelBot = "New2025"


// Settings All Payment
global.dana = "083807449268"
global.ovo = "Tidak Tersedia"
global.gopay = "083807449268"

// Settings Image Url
global.image = {
menu: "https://img101.pixhost.to/images/271/549683307_skyzopedia.jpg", 
reply: "https://img101.pixhost.to/images/271/549683307_skyzopedia.jpg", 
logo: "https://img101.pixhost.to/images/271/549683307_skyzopedia.jpg", 
dana: "https://img101.pixhost.to/images/271/549684093_skyzopedia.jpg", 
ovo: "https://img101.pixhost.to/images/271/549684093_skyzopedia.jpg", 
gopay: "https://img101.pixhost.to/images/271/549684093_skyzopedia.jpg", 
qris: "https://img101.pixhost.to/images/450/553536358_onokosy.jpg"
}

// Settings Api Panel Pterodactyl
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://public-rizx.onokosy.my.id"
global.apikey = "ptla_S2zpNNRA2f9mAXvFpCeVwcqN6Cc2v8GjRR7Ec5wDLI4" //ptla
global.capikey = "ptlc_8kgeotwpbdF" //ptlc

// Settings Api Panel Pterodactyl Server 2
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://publics.onokosy.my.id"
global.apikeyV2 = "ptla_djiJMZcmqOwTYv19dLm2EUljFYL8lUXTzqB0QFd6SiV" //ptla
global.capikeyV2 = "ptlc_hWdEhNCFkpQ3G7Q6NGd93b4KA24twhWeiGRunltKUys" //ptlc

// Settings Api Subdomain
global.subdomain = {
"privatehost.us.kg": {
"zone": "790918217c4add75b7684458518c5836", 
"apitoken": "qYv4NvEN6ZcUIv4dEXihjkmQMwbP_-3Qy_zFlAHv"
}, 
"botwhatsapp.us.kg": {
"zone": "fb1ac418c5564373a56c91d962b30dca", 
"apitoken": "rfQih0XNXiq7AyEuDoLjoFfHX2mhYf_9kddAdKIo"
}, 
"skyzopedia.us.kg": {
"zone": "9e4e70b438a65c1d3e6d0e48b82d79de", 
"apitoken": "odilM9DpvLVPodbPyZwW7UcDKg1aIWsivJc0Vt_o"
}, 
"marketplace.us.kg": {
"zone": "2f33118c3db00b12c38d07cf1c823ed1", 
"apitoken": "6WS_Op6yuPOWcO17NiO-sOP8Vq9tjSAFZyAn82db"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ZPAXx7CL51PtbGweL2pE3BsI3x0hgTgLuy56iXuo"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "HXVf4soYFM3iiOewHZ6tk6LEnG9f7m7CVhU0EoVz"
}, 
"xyz-store.biz.id": {
"zone": "8ae812c35a94b7bd2da993a777b8b16d", 
"apitoken": "oqZafkd3mSt1bABD9MMTidpCtD9VZdiPTjElVKJB"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "4qOupI-Of-6yNrBaeS1-H0KySuKCd0wS-x0P5XQ4"
},
"onokosy.my.id": {
"zone": "dea90e65f035fe922f10b33a1ebfb89b",
"apitoken":"NNmRNuaQZup0q5HhrCFKbQCrtHzJBgVgizBAIezI"
}
}

// Message Command 
global.mess = {
	owner: "* *Akses Ditolak*\nLu Siapa? lu bukan owner gw njir",
	admin: "* *Akses Ditolak*\nFitur ini hanya untuk admin grup!",
	botAdmin: "* *Akses Ditolak*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "* *Akses Ditolak*\nFitur ini hanya untuk dalam grup!",
	private: "* *Akses Ditolak*\nFitur ini hanya untuk dalam private chat!",
	prem: "* *Akses Ditolak*\nFitur ini hanya untuk user premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})